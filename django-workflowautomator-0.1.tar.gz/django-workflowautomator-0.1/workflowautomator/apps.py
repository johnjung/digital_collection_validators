from django.apps import AppConfig


class WorkflowautomatorConfig(AppConfig):
    name = 'workflowautomator'
