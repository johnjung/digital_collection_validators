=====
Workflowautomator
=====

Workflowautomator is a Django app to be added to the Library website intranet. It will help the Preservation department by
keeping track of and automating the validation and sync statuses of some of their materials.

Quick start
-----------

1. Add "workflowautomator" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'workflowautomator.apps.WorkflowautomatorConfig',
    ]

2. Include the workflowautomator URLconf in your project urls.py like this::

    url(r'^workflowautomator/', include('workflowautomator.urls')),

3. Run `python manage.py migrate` to create the polls models.