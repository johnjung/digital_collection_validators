=====
Workflowautomator
=====

Workflowautomator is an app to be added to the Library website intranet. It will help the Preservation department by
keeping track of and automating the validation and sync statuses of some of their materials.

Quick start
-----------

1. Add "workflowautomator" to your INSTALLED_APPS setting like this::

    INSTALLED_APPS = [
        ...
        'workflowautomator.apps.WorkflowautomatorConfig',
    ]

2. Include the workflowautomator URLconf in your project urls.py like this::

    url(r'^workflowautomator/', include('workflowautomator.urls')),

3. Place the following files into a cron job, running as frequently as possible:
    
    utilities/cron_queue_er.py
    utilities/cron_valid_er.py

4. Add the owncloud password to the local config file so it won't be uploaded to GitHub,
and make sure the following files can reference it as 'ocpassword':
    
    views.py
    utilities/cron_queue_er.py
    utilities/cron_valid_er.py
    utilities/sentinelutility.py